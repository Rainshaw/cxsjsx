﻿#include <iostream>
#include <cstring>
#include <cmath>
#include <fstream>

using namespace std;

typedef unsigned short WORD;
typedef unsigned int DWORD;
typedef unsigned int LONG;

#pragma pack(1)
typedef struct tagBITMAPFILEHEADER {
	WORD bfType;
	DWORD bfSize;
	WORD bfReserved1;
	WORD bfReserved2;
	DWORD bfOffBits;
} BITMAPFILEHEADER;


typedef struct tagBITMAPINFOHEADER {
	DWORD biSize;
	LONG biWidth;
	LONG biHeight;
	WORD biPlanes;
	WORD biBitCount;
	DWORD biCompression;
	DWORD biSizeImage;
	LONG biXPelsPerMeter;
	LONG biYPelsPerMeter;
	DWORD biClrUsed;
	DWORD biClrImportant;
} BITMAPINFOHEADER;


int main(int argc, char* argv[]) {

	if (argc != 3) {
		cout << "No enough parameters!\n";
		return 0;
	}

	string srcName = argv[1];
	string destName = argv[2];

	tagBITMAPFILEHEADER filehead;
	tagBITMAPINFOHEADER infohead;
	tagBITMAPINFOHEADER oriInfo;

	fstream readpic, writepic;

	readpic.open(srcName, ios::in | ios::binary);
	writepic.open(destName, ios::out | ios::binary);

	readpic.read((char*)& filehead, sizeof(tagBITMAPFILEHEADER));
	readpic.read((char*)& infohead, sizeof(tagBITMAPINFOHEADER));

	oriInfo = infohead;
	cout << "FILE " << sizeof(tagBITMAPFILEHEADER) << endl << "INFO " << sizeof(tagBITMAPINFOHEADER) << endl;

	int temp = infohead.biWidth;
	infohead.biWidth = infohead.biHeight;
	infohead.biHeight = temp;
	temp = infohead.biXPelsPerMeter;
	infohead.biXPelsPerMeter = infohead.biYPelsPerMeter;
	infohead.biYPelsPerMeter = temp;

	int readnum = infohead.biBitCount / 8;

	writepic.write((char*)& filehead, sizeof(filehead));
	writepic.write((char*)& infohead, sizeof(infohead));
	printf("readnum: %d\n", readnum);

	char** data = new char* [oriInfo.biHeight];

	printf("bitWidth*readnum mod 4=%d\n", readnum * oriInfo.biWidth % 4);
	printf("bitWidth*readnum=%d\n", readnum * oriInfo.biWidth);

	int sWidth = readnum * oriInfo.biWidth % 4 == 0 ? readnum * oriInfo.biWidth : (readnum * oriInfo.biWidth / 4 + 1) * 4;

	printf("sWidth:%d\n", sWidth);

	for (int i = 0; i < oriInfo.biHeight; i++) {
		*(data + i) = new char[sWidth];
	}

	for (int i = oriInfo.biHeight - 1; i >= 0; i--) {
		for (int j = 0; j < sWidth; j++) {
			readpic.read(*(data + i) + j, 1);
		}
	}

	char zero[5] = { 0 };
	for (int j = oriInfo.biWidth - 1; j >= 0; j--) {
		for (int i = oriInfo.biHeight - 1; i >= 0; i--) {
			writepic.write(*(data + i) + readnum * j, readnum);
		}
		if ((infohead.biWidth * readnum) % 4 != 0) {
			writepic.write(zero, 4 - (infohead.biWidth * readnum) % 4);
		}
	}
	readpic.close();
	writepic.close();
	return 0;

}